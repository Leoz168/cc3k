#include "GameObject.h"
GameObject::GameObject(int x, int y, int id, int room_number, int tile_type): Tile{x, y, id, room_number, tile_type} {}
