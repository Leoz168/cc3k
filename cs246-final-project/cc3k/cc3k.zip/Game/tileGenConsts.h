#ifndef TILEGENCONSTS_H
#define TILEGENCONSTS_H

const int NOASSOCIATEDROOM = -1;

#endif
