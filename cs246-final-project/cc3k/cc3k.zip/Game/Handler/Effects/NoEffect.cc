#include "NoEffect.h"
NoEffect::NoEffect() {}
int NoEffect::getAtkModifier() { return 0; }
int NoEffect::getDefModifier() { return 0; }
NoEffect::~NoEffect() {}
