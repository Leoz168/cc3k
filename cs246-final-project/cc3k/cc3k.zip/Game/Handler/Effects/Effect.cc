#include "Effect.h"
Effect::Effect() {}
