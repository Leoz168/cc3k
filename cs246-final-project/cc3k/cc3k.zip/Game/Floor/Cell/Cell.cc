#include "Cell.h"

using namespace std;

Cell::Cell(int x, int y, int id, int room_number) : Tile{x, y, id, room_number} {}
