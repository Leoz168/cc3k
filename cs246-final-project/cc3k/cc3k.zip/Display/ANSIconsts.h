#include <string>
const std::string CLEAR_COMMAND = "\x1B[2J\x1B[H";
